package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.ui.theme.AmarilloPrincipal
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromocionesScreen(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var productoSeleccionado by remember { mutableStateOf<Producto?>(null) }

    MenuLateral(
        viewModel = viewModel,
        navController = navController
    ) {
        val productosEnOferta = viewModel.productos.filter { it.enOferta }

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->

            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    if (productosEnOferta.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "No hay productos en oferta",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }

                    items(productosEnOferta) { producto ->

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { productoSeleccionado = producto },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.gato),
                                    contentDescription = producto.nombre,
                                    modifier = Modifier.size(80.dp),
                                    contentScale = ContentScale.Crop
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        producto.nombre,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))

                                    producto.precioAntes?.let { antes ->
                                        Text(
                                            "Antes: $$antes",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = AmarilloPrincipal
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                    }
                                    Text(
                                        "Ahora: $${producto.precio}",
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = {
                                            viewModel.agregarAlCarrito(producto.id!!)
                                            scope.launch {
                                                snackbarHostState.showSnackbar(
                                                    message = "${producto.nombre} agregado al carrito",
                                                    duration = SnackbarDuration.Short
                                                )
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color.White,
                                            contentColor = Color.Black
                                        )
                                    ) {
                                        Text("Agregar al carrito", color = Color.Black)
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(Modifier.height(24.dp)) }
                }

                productoSeleccionado?.let { prod ->
                    DetalleProductoSheet(
                        producto = prod,
                        viewModel = viewModel,
                        onCerrar = { productoSeleccionado = null },
                        snackbarHostState = snackbarHostState,
                        scope = scope
                    )
                }
            }
        }
    }
}
