package com.example.evatiendadeportes.Model

data class Producto(
    val id: Long? = null,
    val nombre: String,
    val precio: Double,
    val descripcion: String,
    val categoria: Categoria?,
    val enOferta: Boolean = false,
    val precioAntes: Int? = null,
    val stock: Int,
    val imagenResId: Int? = null

)