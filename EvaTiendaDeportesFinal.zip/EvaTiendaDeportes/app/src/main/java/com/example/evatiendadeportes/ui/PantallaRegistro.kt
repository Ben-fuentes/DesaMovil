package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Rol
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable
fun PantallaRegistro(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    var nombreCompleto by remember { mutableStateOf("") }
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    var metodoPago by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf("") }

    val colores = MaterialTheme.colorScheme

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colores.background
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "Registro de nuevo usuario",
                style = MaterialTheme.typography.headlineSmall,
                color = colores.onBackground
            )

            Spacer(Modifier.height(24.dp))

            // ---------- NOMBRE COMPLETO ----------
            OutlinedTextField(
                value = nombreCompleto,
                onValueChange = { nombreCompleto = it },
                label = { Text("Nombre completo") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedLabelColor = colores.primary,
                    unfocusedLabelColor = Color.Black,
                    cursorColor = colores.primary
                )
            )

            Spacer(Modifier.height(16.dp))

            // ---------- USUARIO ----------
            OutlinedTextField(
                value = usuario,
                onValueChange = { usuario = it },
                label = { Text("Nombre de usuario") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedLabelColor = colores.primary,
                    unfocusedLabelColor = Color.Black,
                    cursorColor = colores.primary
                )
            )

            Spacer(Modifier.height(16.dp))

            // ---------- CONTRASEÑA ----------
            OutlinedTextField(
                value = contrasena,
                onValueChange = { contrasena = it },
                label = { Text("Contraseña") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedLabelColor = colores.primary,
                    unfocusedLabelColor = Color.Black,
                    cursorColor = colores.primary
                )
            )

            Spacer(Modifier.height(24.dp))

            // ---------- BOTÓN REGISTRAR ----------
            Button(
                onClick = {
                    val exito = viewModel.registrarUsuario(
                        nombre = nombreCompleto.ifBlank { usuario },
                        nombreUsuario = usuario,
                        contrasena = contrasena,
                        rol = Rol.CLIENTE,
                        metodoPago = if (metodoPago.isBlank()) null else metodoPago
                    ) { ok, mensaje ->
                        if (ok) {
                            navController.navigate("inicio_sesion") {
                                popUpTo("registro") { inclusive = true }
                            }
                        } else {
                            mensajeError = mensaje ?: "Error al registrar"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colores.primary,
                    contentColor = Color.White
                )
            ) {
                Text("Registrar")
            }

            if (mensajeError.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text(mensajeError, color = colores.error)
            }

            Spacer(Modifier.height(16.dp))

            // ---------- BOTÓN IR A LOGIN ----------
            TextButton(onClick = { navController.navigate("inicio_sesion") }) {
                Text(
                    "¿Ya tienes cuenta? Inicia sesión",
                    color = colores.onPrimary
                )
            }
        }
    }
}
