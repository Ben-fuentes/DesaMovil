package com.example.evatiendadeportes.ui


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import androidx.compose.ui.graphics.Color

@Composable
fun ConfirmacionDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    viewModel: ProductoViewModel,
    onVerPedido: () -> Unit
) {
    val pedido = viewModel.ultimoPedido

    if (!showDialog || pedido == null) return

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Pedido Confirmado")
                IconButton(onClick = onDismiss) {
                    Text("X")
                }
            }
        },
        text = {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Text("Tu pedido fue confirmado")
                Spacer(Modifier.height(8.dp))
                Text("Número de pedido: ${pedido.numeroPedido}")
            }
        },
        confirmButton = {
            Button(
                onClick = onVerPedido,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) { Text("Ver Pedido") }
        }
    )
}
