package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerfilScreen(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    MenuLateral(viewModel = viewModel, navController = navController) {

        val usuario = viewModel.usuarioActual.value

        if (usuario == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No hay usuario autenticado.")
            }
            return@MenuLateral
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painter = painterResource(id = R.drawable.avatardefault),
                contentDescription = "Foto de perfil",
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // ---------- DATOS ----------
            Text(usuario.nombreCompleto, style = MaterialTheme.typography.titleLarge)
            Text("@${usuario.nombreUser}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))

            Text("Rol: ${usuario.rol}", style = MaterialTheme.typography.bodyMedium)

            Text(
                "Método de pago: ${usuario.metodoPago ?: "No registrado"}",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(30.dp))

            // ---------- PEDIDOS ----------
            Text("Tus pedidos", style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(12.dp))

            val pedido = viewModel.ultimoPedido

            if (pedido == null) {
                Text("No tienes pedidos aún.", style = MaterialTheme.typography.bodySmall)
            } else {
                Button(
                    onClick = { navController.navigate("verpedido") },
                    modifier = Modifier.fillMaxWidth(0.8f) ,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
                ) {
                    Text("Ver último pedido")
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

        }
    }
}
