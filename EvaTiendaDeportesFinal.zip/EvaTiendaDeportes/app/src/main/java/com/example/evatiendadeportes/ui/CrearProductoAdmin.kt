package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.ui.theme.AzulOscuro
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable
fun CrearProductoAdmin(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    if (!viewModel.esAdministrador()) {
        Text("Acceso denegado: solo administradores")
        return
    }

    var nombre by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf<Categoria?>(null) }
    var mensajeExito by remember { mutableStateOf<String?>(null) }

    // Mapear categoría → imagen por defecto
    val imagenPorCategoria = mapOf(
        Categoria.BMX to R.drawable.bmx,
        Categoria.SKATE to R.drawable.skte,
        Categoria.ROLLER to R.drawable.roller
    )

    val colores = MaterialTheme.colorScheme

    MenuLateral(viewModel, navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre del producto") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = precio,
                onValueChange = { precio = it },
                label = { Text("Precio") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = stock,
                onValueChange = { stock = it },
                label = { Text("Stock") },
                modifier = Modifier.fillMaxWidth()
            )

            // Dropdown Categorías
            DropdownCategorias(
                selected = categoria,
                onSelect = { categoria = it }
            )

            // Imagen de vista previa según categoría
            categoria?.let {
                val imagenResId = imagenPorCategoria[it] ?: R.drawable.gato
                Image(
                    painter = painterResource(id = imagenResId),
                    contentDescription = "Imagen de vista previa",
                    modifier = Modifier
                        .height(120.dp)
                        .fillMaxWidth()
                )
            }

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    val precioDouble = precio.toDoubleOrNull()
                    val stockInt = stock.toIntOrNull()

                    if (nombre.isBlank() ||
                        descripcion.isBlank() ||
                        precioDouble == null || precioDouble <= 0 ||
                        stockInt == null || stockInt <= 0 ||
                        categoria == null
                    ) {
                        mensajeExito = "Completa todos los campos correctamente"
                        return@Button
                    }

                    viewModel.crearProducto(
                        nombre.trim(),
                        precioDouble,
                        descripcion.trim(),
                        categoria!!,
                        stockInt
                    )

                    // Limpiar campos
                    nombre = ""
                    precio = ""
                    descripcion = ""
                    stock = ""
                    categoria = null

                    // Mostrar mensaje de éxito
                    mensajeExito = "Producto creado correctamente"
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) {
                Text("Crear Producto")
            }

            // Mostrar mensaje
            mensajeExito?.let { msg ->
                Text(
                    text = msg,
                    color = if (msg.contains("correctamente", true)) Color.Green else Color.Red,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun DropdownCategorias(
    selected: Categoria?,
    onSelect: (Categoria) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Button(
            onClick = { expanded = true },
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        ) {
            Text(selected?.name ?: "Seleccionar categoría")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            Categoria.values().forEach { cat ->
                DropdownMenuItem(
                    text = { Text(cat.name) },
                    onClick = {
                        onSelect(cat)
                        expanded = false
                    }
                )
            }
        }
    }
}