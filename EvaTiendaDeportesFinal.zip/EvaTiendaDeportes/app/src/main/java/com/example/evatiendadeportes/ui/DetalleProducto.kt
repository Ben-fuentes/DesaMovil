package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import com.example.evatiendadeportes.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalleProductoSheet(
    producto: Producto,
    viewModel: ProductoViewModel,
    onCerrar: () -> Unit,
    snackbarHostState: SnackbarHostState,
    scope: CoroutineScope
) {
    val scroll = rememberScrollState()

    var colorSeleccionado by remember { mutableStateOf("Rojo") }
    var tallaSeleccionada by remember { mutableStateOf("M") }

    ModalBottomSheet(
        onDismissRequest = { onCerrar() },
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(scroll)
        ) {

            // IMAGEN
            Image(
                painter = painterResource(id = R.drawable.gato),
                contentDescription = producto.nombre,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )

            Spacer(Modifier.height(16.dp))

            // NOMBRE Y PRECIO
            Text(producto.nombre, style = MaterialTheme.typography.headlineSmall)
            Text("Precio: $${producto.precio}", style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(12.dp))

            // DESCRIPCIÓN
            Text(producto.descripcion)

            Spacer(Modifier.height(20.dp))

            // SELECTOR COLOR
            Text("Color:", style = MaterialTheme.typography.titleMedium)
            Row {
                listOf("Rojo", "Azul", "Negro").forEach { color ->
                    AssistChip(
                        onClick = { colorSeleccionado = color },
                        label = { Text(color) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (colorSeleccionado == color)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Text("Talla:", style = MaterialTheme.typography.titleMedium)
            Row {
                listOf("S", "M", "L", "XL").forEach { talla ->
                    AssistChip(
                        onClick = { tallaSeleccionada = talla },
                        label = { Text(talla) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (tallaSeleccionada == talla)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }

            Spacer(Modifier.height(25.dp))

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    viewModel.agregarAlCarrito(producto.id!!)
                    scope.launch {
                        snackbarHostState.showSnackbar(
                            message = "${producto.nombre} agregado al carrito",
                            duration = SnackbarDuration.Short
                        )
                    }
                    onCerrar()
                }
            ) {
                Text("Agregar al carrito")
            }

            Spacer(Modifier.height(30.dp))
        }
    }
}