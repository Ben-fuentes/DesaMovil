package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.ui.theme.AzulOscuro
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable
fun PantallaCarrito(viewModel: ProductoViewModel, navController: NavController) {
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    MenuLateral(viewModel = viewModel, navController = navController) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            PantallaCarritoContenido(
                viewModel = viewModel,
                onShowCheckout = { showCheckoutDialog = true }
            )
        }
    }

    // ----------------- Checkout -----------------
    // Este diálogo ya llama internamente a viewModel.crearPedidoYConfirmar
    CheckoutDialog(
        showDialog = showCheckoutDialog,
        onDismiss = { showCheckoutDialog = false },
        viewModel = viewModel,
        onConfirm = { _ ->
            // CORRECCIÓN: Quitamos viewModel.crearPedidoPendiente(metodoPago)
            // porque eso creaba un pedido vacío sobrescribiendo al real.
            showCheckoutDialog = false
            showConfirmDialog = true
        }
    )

    // ----------------- Confirmación -----------------
    ConfirmacionDialog(
        showDialog = showConfirmDialog,
        onDismiss = { showConfirmDialog = false },
        viewModel = viewModel,
        onVerPedido = {
            showConfirmDialog = false
            navController.navigate("verPedido")
        }
    )
}

@Composable
fun PantallaCarritoContenido(
    viewModel: ProductoViewModel,
    onShowCheckout: () -> Unit
) {
    LaunchedEffect(Unit) {
        viewModel.mensaje.value = null
    }
    val carrito = viewModel.carrito
    val total by remember { derivedStateOf { viewModel.totalCarrito() } }
    val c = MaterialTheme.colorScheme

    if (carrito.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Tu carrito está vacío.", color = c.onBackground)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(carrito) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = c.surface,
                            contentColor = c.onSurface
                        )
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(item.producto.nombre, style = MaterialTheme.typography.titleMedium)
                            Text("Precio: $${item.producto.precio}")
                            Text("Subtotal: $${item.subtotal}")

                            Spacer(Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row {
                                    FilledTonalButton(
                                        onClick = { viewModel.cambiarCantidad(item.producto.id, -1) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = c.primary,
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier.size(32.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) { Text("-") }

                                    Spacer(Modifier.width(8.dp))
                                    Text("${item.cantidad}")
                                    Spacer(Modifier.width(8.dp))

                                    FilledTonalButton(
                                        onClick = { viewModel.cambiarCantidad(item.producto.id, 1) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = c.primary,
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier.size(32.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) { Text("+") }
                                }

                                Button(
                                    onClick = { viewModel.eliminarDelCarrito(item.producto.id!!) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = c.primary,
                                        contentColor = Color.White
                                    )
                                ) { Text("Eliminar") }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Total: $${"%.2f".format(total)}",
                style = MaterialTheme.typography.titleLarge,
                color = c.onBackground
            )

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = { viewModel.vaciarCarrito() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = c.primary,
                    contentColor = Color.White
                )
            ) { Text("Vaciar Carrito") }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onShowCheckout,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = c.primary,
                    contentColor = Color.White
                )
            ) { Text("Proceder al pago") }
        }
    }
}