package com.example.evatiendadeportes.Model

enum class Estado {PENDIENTE, CONFIRMADO, CANCELADO}
data class Pedido(
    val id: Long? =null ,
    val numeroPedido: Int,
    val productos: List<Producto>,
    val total: Double,
    val usuario: Usuario,
    val estado: Estado = Estado.PENDIENTE
)
