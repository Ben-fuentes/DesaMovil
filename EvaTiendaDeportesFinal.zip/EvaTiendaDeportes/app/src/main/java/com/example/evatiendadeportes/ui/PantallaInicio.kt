package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable

fun PantallaInicioSesion(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    LaunchedEffect(Unit) {
        viewModel.mensaje.value = null
    }
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }

    val focusUsuario = remember { FocusRequester() }
    val focusContrasena = remember { FocusRequester() }

    val keyboardController = LocalSoftwareKeyboardController.current
    val mensaje = viewModel.mensaje.value
    val usuarioActual = viewModel.usuarioActual.value
    val colores = MaterialTheme.colorScheme

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colores.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {

            Image(
                painter = painterResource(id = R.drawable.fondo),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.3f
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.2f))
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.gato),
                    contentDescription = "Logo",
                    modifier = Modifier.size(160.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    "KB APP",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White ,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = usuario,
                    onValueChange = { usuario = it },
                    placeholder = { Text("Nombre de usuario", color = Color.Black) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusUsuario),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(
                        onNext = { focusContrasena.requestFocus() }
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedLabelColor = colores.primary,
                        unfocusedLabelColor = Color.Black,
                        cursorColor = colores.primary,
                        focusedIndicatorColor = Color.Black,
                        unfocusedIndicatorColor = Color.Black
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                OutlinedTextField(
                    value = contrasena,
                    onValueChange = { contrasena = it },
                    placeholder = { Text("Contraseña", color = Color.Black) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusContrasena),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = { keyboardController?.hide() }
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedLabelColor = colores.primary,
                        unfocusedLabelColor = Color.Black,
                        cursorColor = colores.primary,
                        focusedIndicatorColor = Color.Black,
                        unfocusedIndicatorColor = Color.Black
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.iniciarSesion(usuario, contrasena) { ok, mensaje ->
                            if (ok) {
                                viewModel.mensaje.value = ""
                                val rol = viewModel.usuarioActual.value?.rol
                                navController.navigate(
                                    if (rol == com.example.evatiendadeportes.Model.Rol.ADMIN)
                                        "admin"
                                    else "catalogo"
                                ) {
                                    popUpTo("inicio_sesion") { inclusive = true }
                                }
                            } else {
                                // Mostrar error
                                viewModel.mensaje.value = mensaje
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colores.primary,
                        contentColor = Color.White
                    )
                ) {
                    Text("Ingresar")
                }


                Spacer(modifier = Modifier.height(12.dp))


                if (!mensaje.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        mensaje,
                        color = colores.error,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 18.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                TextButton(onClick = { navController.navigate("registro") }) {
                    Text(
                        "¿No tienes cuenta? Regístrate aquí",
                        color = colores.onPrimary
                    )
                }
                TextButton(
                    onClick = { navController.navigate("recuperar_contraseña") },
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text("¿Olvidaste tu contraseña?", color = colores.onPrimary)
                }
            }
        }
    }
}
