package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.ui.theme.AzulOscuro
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import androidx.compose.ui.Alignment


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaAdmin(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    // Verificación de administrador
    val usuario = viewModel.usuarioActual.value
    if (usuario?.rol != com.example.evatiendadeportes.Model.Rol.ADMIN) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Acceso denegado: solo administradores",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.error
            )
        }
        return
    }

    val colores = MaterialTheme.colorScheme

    MenuLateral(viewModel = viewModel, navController = navController) {
        Scaffold(containerColor = colores.background) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "Panel de Administración",
                    style = MaterialTheme.typography.titleLarge,
                    color = colores.onBackground
                )

                Button(
                    onClick = { navController.navigate("crear_producto") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("Crear Producto")
                }

                Button(
                    onClick = { navController.navigate("listado_productos") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("Listado Productos")
                }
            }
        }
    }
}