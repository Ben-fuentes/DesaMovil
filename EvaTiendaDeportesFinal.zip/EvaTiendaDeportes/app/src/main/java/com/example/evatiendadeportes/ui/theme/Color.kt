package com.example.evatiendadeportes.ui.theme

import androidx.compose.ui.graphics.Color

val Blanco = Color(0xFFFFFFFF)
val NegroCard = Color(0xFF1E1E1E)


val PrincipalAzul = Color(0xFF305BFF)

val AzulOscuro = Color(0xED0037C2)
val AmarilloPrincipal = Color(0xFFD4AF37)

val GrispelaoOsc = Color(0xFF464646)

val RojoError = Color.Red

val Grispelao = Color(0xFF6C6C6C)

val NegroFondo = Color(0xFF111111)

val BlancoSuave = Color(0xFFE8E8E8)
val GrisTexto = Color(0xFFDDDDDD)

val CafePrincipalDark = Color(0xFF8A3A00)

val CafeOscuroDark = Color(0xFF5E2600)


