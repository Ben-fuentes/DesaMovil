package com.example.evatiendadeportes


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.evatiendadeportes.ui.*

import com.example.evatiendadeportes.ui.theme.EvaTiendaDeportesTheme
import com.example.evatiendadeportes.ui.PromocionesScreen
import com.example.evatiendadeportes.ui.RecuperarContraScreen
import com.example.evatiendadeportes.ui.VerPedidoScreen
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val viewModel: ProductoViewModel by viewModels()

            EvaTiendaDeportesTheme() {
                Surface(color = MaterialTheme.colorScheme.background) {
                    NavHost(
                        navController = navController,
                        startDestination = "inicio_sesion"
                    ) {
                        composable("inicio_sesion") {
                            PantallaInicioSesion(viewModel, navController)
                        }
                        composable("registro") {
                            PantallaRegistro(viewModel, navController)
                        }

                        composable("catalogo") {
                            PantallaCatalogo(viewModel, navController)
                        }
                        composable("carrito") {
                            PantallaCarrito(viewModel, navController)
                        }
                        composable("quienes_somos") {
                            PantallaQuienesSomos(viewModel, navController)
                        }
                        composable("admin") {
                            PantallaAdmin(viewModel, navController)
                        }
                        composable("crear_producto") {
                            CrearProductoAdmin(viewModel, navController)
                        }

                        composable("listado_productos") {
                            ListadoProductosAdmin(viewModel, navController)
                        }
                        composable("clientes") {
                            PantallaClientes(viewModel, navController)
                        }
                        composable("dashboard_admin") {
                            DashboardAdminScreen(navController, viewModel)
                        }
                        composable("recuperar_contraseña") {
                            RecuperarContraScreen(viewModel, navController)
                        }
                        composable("promociones") {
                            PromocionesScreen(viewModel, navController, )
                        }

                        composable("verPedido") {
                            VerPedidoScreen(navController, viewModel)
                        }
                        composable("perfil") {
                            PerfilScreen(viewModel, navController, )
                        }
                    }
                }
            }
        }}}