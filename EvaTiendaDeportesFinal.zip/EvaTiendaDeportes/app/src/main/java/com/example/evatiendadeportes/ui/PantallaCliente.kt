package com.example.evatiendadeportes.ui


import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.evatiendadeportes.Model.Usuario
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.viewmodel.ProductoViewModel


@Composable
fun PantallaClientes(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    MenuLateral(
        viewModel = viewModel,
        navController = navController
    ) {
        ClientesContenido(viewModel)
    }
}

@Composable
fun ClientesContenido(viewModel: ProductoViewModel) {
    val usuarios = viewModel.usuarios

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        items(usuarios) { usuario ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Nombre: ${usuario.nombreCompleto}")
                    Text("Usuario: ${usuario.nombreUser}")
                    Text("Rol: ${usuario.rol}")
                    Text("Método de pago: ${usuario.metodoPago ?: "No definido"}")
                }
            }
        }
    }
}