package com.example.evatiendadeportes.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch

@Composable
fun PantallaCatalogo(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    MenuLateral(viewModel, navController) {
        PantallaCatalogoContenido(viewModel)
    }
}

@Composable
fun PantallaCatalogoContenido(
    viewModel: ProductoViewModel,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(Unit) {
        viewModel.mensaje.value = null
    }

    var filtro by remember { mutableStateOf("A-Z") }
    var productoSeleccionado by remember { mutableStateOf<Producto?>(null) }
    val colores = MaterialTheme.colorScheme
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { paddingValues ->

        Box(modifier = modifier.fillMaxSize()) {

            // Fondo
            Image(
                painter = painterResource(id = R.drawable.catfondo),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.3f
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.2f))
            )

            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {

                FiltroCatalogo(filtroActual = filtro, onFiltroCambiar = { filtro = it })

                Spacer(Modifier.height(16.dp))

                LazyColumn {
                    Categoria.values().forEach { categoria ->

                        // MODIFICADO: Filtramos para que solo salgan los que tienen Stock > 0
                        val productosOriginales = viewModel.productosPorCategoria(categoria)
                            .filter { it.stock > 0 }

                        val productosFiltrados = when (filtro) {
                            "A-Z" -> productosOriginales.sortedBy { it.nombre }
                            "Z-A" -> productosOriginales.sortedByDescending { it.nombre }
                            "Precio ↑" -> productosOriginales.sortedBy { it.precio }
                            "Precio ↓" -> productosOriginales.sortedByDescending { it.precio }
                            else -> productosOriginales
                        }

                        if (productosFiltrados.isNotEmpty()) {
                            item {
                                Text(
                                    text = categoria.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colores.onPrimary,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .wrapContentWidth(Alignment.CenterHorizontally)
                                )
                                Spacer(Modifier.height(8.dp))
                            }

                            items(productosFiltrados) { producto ->

                                // Imagen según categoría
                                val imagenResId = when (producto.categoria) {
                                    Categoria.BMX -> R.drawable.bmx
                                    Categoria.SKATE -> R.drawable.skte
                                    Categoria.ROLLER -> R.drawable.roller
                                    else -> R.drawable.gato
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                        .clickable { productoSeleccionado = producto },
                                    colors = CardDefaults.cardColors(
                                        containerColor = colores.primary
                                    )
                                ) {
                                    Row(modifier = Modifier.padding(16.dp)) {

                                        Image(
                                            painter = painterResource(id = imagenResId),
                                            contentDescription = "Imagen del producto",
                                            modifier = Modifier
                                                .size(80.dp)
                                                .padding(end = 12.dp),
                                            contentScale = ContentScale.Crop
                                        )

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                producto.nombre,
                                                style = MaterialTheme.typography.titleLarge,
                                                color = Color.White
                                            )
                                            Text(
                                                producto.descripcion,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = Color.White
                                            )
                                            Text(
                                                "Precio: $${producto.precio}",
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = Color.White
                                            )

                                            Spacer(Modifier.height(8.dp))

                                            Button(
                                                onClick = {
                                                    viewModel.agregarAlCarrito(producto.id!!)
                                                    scope.launch {
                                                        snackbarHostState.showSnackbar(
                                                            message = "${producto.nombre} agregado al carrito",
                                                            duration = SnackbarDuration.Short
                                                        )
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color.White,
                                                    contentColor = Color.Black
                                                )
                                            ) {
                                                Text("Agregar al carrito", color = Color.Black)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item { Spacer(Modifier.height(24.dp)) }
                    }
                }
            }

            // Detalle del producto
            productoSeleccionado?.let { prod ->
                DetalleProductoSheet(
                    producto = prod,
                    viewModel = viewModel,
                    onCerrar = { productoSeleccionado = null },
                    snackbarHostState = snackbarHostState,
                    scope = scope
                )
            }
        }
    }
}

@Composable
fun FiltroCatalogo(
    filtroActual: String,
    onFiltroCambiar: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(
            onClick = { expanded = true },
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onSurface
            )
        ) {
            Text("Ordenar: $filtroActual")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(text = { Text("A-Z") }, onClick = {
                onFiltroCambiar("A-Z")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Z-A") }, onClick = {
                onFiltroCambiar("Z-A")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Precio ↑") }, onClick = {
                onFiltroCambiar("Precio ↑")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Precio ↓") }, onClick = {
                onFiltroCambiar("Precio ↓")
                expanded = false
            })
        }
    }
}