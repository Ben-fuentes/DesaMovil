package com.example.evatiendadeportes.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.Model.Estado
import com.example.evatiendadeportes.Model.Pedido
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.Model.Rol
import com.example.evatiendadeportes.Model.Usuario
import com.example.evatiendadeportes.dao.PedidoDao
import com.example.evatiendadeportes.dao.ProductoDao
import com.example.evatiendadeportes.remote.RetrofitClient
import kotlinx.coroutines.launch

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

data class ItemCarrito(val producto: Producto, var cantidad: Int = 1) {
    val subtotal: Double get() = producto.precio * cantidad
}

class ProductoViewModel : ViewModel() {

    private val pedidoDao = PedidoDao()

    val usuarios = mutableStateListOf<Usuario>()
    var usuarioActual = mutableStateOf<Usuario?>(null)

    private val _productos = mutableStateListOf<Producto>()
    private val productoDao = ProductoDao()
    val productos: List<Producto> get() = _productos

    private val _pedidos = mutableStateListOf<Pedido>()
    val pedidos: List<Pedido> get() = _pedidos

    var ultimoPedido by mutableStateOf<Pedido?>(null)

    val carrito = mutableStateListOf<ItemCarrito>()

    var mensaje = mutableStateOf<String?>(null)
    var mensajeRapido = mutableStateOf<String?>(null)

    val api = RetrofitClient.api
    var productoMostrado = mutableStateOf<Producto?>(null)

    init {
        cargarProductosDesdeApi()
        cargarUsuarios()
    }

    // ----------------- Autenticación -----------------
    fun iniciarSesion(nombreUsuario: String, contrasena: String, onResult: (Boolean, String?) -> Unit) {
        api.getUsuarios().enqueue(object : Callback<List<Usuario>> {
            override fun onResponse(call: Call<List<Usuario>>, response: Response<List<Usuario>>) {
                val usuario = response.body()?.find { it.nombreUser == nombreUsuario && it.contrasenia == contrasena }
                if (usuario != null) {
                    usuarioActual.value = usuario
                    onResult(true, null)
                } else {
                    onResult(false, "Usuario o contraseña incorrectos")
                }
            }
            override fun onFailure(call: Call<List<Usuario>>, t: Throwable) {
                onResult(false, "Error de conexión: ${t.message}")
            }
        })
    }

    fun registrarUsuario(nombre: String, nombreUsuario: String, contrasena: String, rol: Rol = Rol.CLIENTE, metodoPago: String? = null, onResult: (Boolean, String?) -> Unit) {
        val nuevoUsuario = Usuario(nombreCompleto = nombre, id = null, nombreUser = nombreUsuario, contrasenia = contrasena, rol = rol, metodoPago = metodoPago)
        RetrofitClient.api.crearUsuario(nuevoUsuario).enqueue(object : Callback<Usuario> {
            override fun onResponse(call: Call<Usuario>, response: Response<Usuario>) {
                if (response.isSuccessful) onResult(true, "Usuario creado correctamente") else onResult(false, "Error al registrar usuario")
            }
            override fun onFailure(call: Call<Usuario>, t: Throwable) {
                onResult(false, "Error de conexión: ${t.message}")
            }
        })
    }

    fun actualizarContrasena(nombreUsuario: String, nuevaContrasena: String, onResult: (Boolean, String?) -> Unit) {
        api.getUsuarios().enqueue(object : Callback<List<Usuario>> {
            override fun onResponse(call: Call<List<Usuario>>, response: Response<List<Usuario>>) {
                val usuario = response.body()?.find { it.nombreUser == nombreUsuario }
                if (usuario != null) {
                    val actualizado = usuario.copy(contrasenia = nuevaContrasena, rol = usuario.rol ?: Rol.CLIENTE)
                    api.actualizarUsuario(usuario.id!!, actualizado).enqueue(object : Callback<Usuario> {
                        override fun onResponse(call: Call<Usuario>, response: Response<Usuario>) { if (response.isSuccessful) onResult(true, "Ok") else onResult(false, "Error") }
                        override fun onFailure(call: Call<Usuario>, t: Throwable) { onResult(false, "Error") }
                    })
                } else onResult(false, "Usuario no encontrado")
            }
            override fun onFailure(call: Call<List<Usuario>>, t: Throwable) { onResult(false, "Error") }
        })
    }

    fun cerrarSesion() {
        usuarioActual.value = null
        carrito.clear()
        mensaje.value = "Sesión cerrada"
    }
    fun esAdministrador(): Boolean = usuarioActual.value?.rol == Rol.ADMIN

    // ----------------- Productos (CRUD) -----------------
    fun crearProducto(nombre: String, precio: Double, descripcion: String, categoria: Categoria, stock: Int, imagen: Int? = null) {
        if (!esAdministrador()) { mensaje.value = "Solo admin"; return }
        val nuevo = Producto(null, nombre, precio, descripcion, categoria, false, null, stock)
        productoDao.crearProducto(nuevo) { creado -> if (creado != null) _productos.add(creado) }
    }

    fun modificarProducto(id: Long, nombre: String, precio: Double?, descripcion: String, categoria: Categoria?): Boolean {
        if (!esAdministrador()) return false
        val idx = _productos.indexOfFirst { it.id == id }
        if (idx == -1) return false
        val ant = _productos[idx]
        _productos[idx] = Producto(id, nombre.trim(), precio ?: ant.precio, descripcion.trim(), categoria ?: ant.categoria, ant.enOferta, ant.precioAntes, ant.stock)
        mensaje.value = "Modificado"
        return true
    }

    fun eliminarProducto(id: Long, onResult: (Boolean) -> Unit = {}) {
        if (!esAdministrador()) { onResult(false); return }
        productoDao.borrarProducto(id) { ok ->
            if (ok) { _productos.removeIf { it.id == id }; onResult(true) } else onResult(false)
        }
    }

    fun productosPorCategoria(cat: Categoria) = _productos.filter { it.categoria == cat }
    fun buscarProductoPorId(id: Long) = _productos.firstOrNull { it.id == id }

    // ----------------- Carrito -----------------
    fun agregarAlCarrito(id: Long, cant: Int = 1) {
        val p = buscarProductoPorId(id) ?: return
        val idx = carrito.indexOfFirst { it.producto.id == id }
        if (idx != -1) carrito[idx] = carrito[idx].copy(cantidad = carrito[idx].cantidad + cant)
        else carrito.add(ItemCarrito(p, cant.coerceAtLeast(1)))
        mensajeRapido.value = "Agregado"
    }
    fun eliminarDelCarrito(id: Long) { carrito.removeIf { it.producto.id == id } }
    fun cambiarCantidad(id: Long?, delta: Int) {
        val idx = carrito.indexOfFirst { it.producto.id == id }
        if (idx == -1) return
        val item = carrito[idx]
        val nueva = item.cantidad + delta
        if (nueva <= 0) carrito.removeAt(idx) else carrito[idx] = item.copy(cantidad = nueva)
    }
    fun totalCarrito(): Double = carrito.sumOf { it.subtotal }
    fun vaciarCarrito() { carrito.clear() }


    // ----------------- PEDIDOS Y COMPRA (LOGICA LOCAL + API) -----------------

    fun crearPedidoYConfirmar(metodoPagoSeleccionado: String, onResult: (Boolean) -> Unit) {
        val usuario = usuarioActual.value ?: run { onResult(false); return }

        // 1. [IMPORTANTE] CAPTURAR DATOS LOCALES DEL CARRITO AHORA MISMO
        // flatMap expande la cantidad. Si tienes 2 'zapatillas', crea una lista con 2 objetos 'zapatilla'
        val productosLocales = carrito.flatMap { item -> List(item.cantidad) { item.producto } }
        val totalLocal = totalCarrito()

        // 2. Actualizar método de pago en API
        val usuarioActualizado = usuario.copy(metodoPago = metodoPagoSeleccionado)
        RetrofitClient.api.actualizarUsuario(usuario.id!!, usuarioActualizado).enqueue(object : retrofit2.Callback<Usuario> {
            override fun onResponse(call: retrofit2.Call<Usuario>, response: retrofit2.Response<Usuario>) {
                if (response.isSuccessful) {
                    usuarioActual.value = usuarioActualizado

                    // 3. Crear pedido en API (usamos la lista local para enviarla)
                    pedidoDao.crearPedido(usuario.id!!, productosLocales) { pedidoCreado ->
                        if (pedidoCreado != null) {
                            // 4. Confirmar pedido en API
                            pedidoDao.confirmarPedido(pedidoCreado.id!!) { ok ->
                                if (ok) {
                                    // 5. [IMPORTANTE] FORZAR LOS DATOS LOCALES EN EL ULTIMO PEDIDO
                                    // No usamos lo que devuelve la API para mostrar en pantalla, usamos lo que teníamos en el carrito
                                    ultimoPedido = pedidoCreado.copy(
                                        estado = Estado.CONFIRMADO,
                                        usuario = usuarioActualizado,
                                        productos = productosLocales, // <--- Lista llena
                                        total = totalLocal            // <--- Total correcto
                                    )
                                    _pedidos.add(ultimoPedido!!)

                                    descontarStockDeCarrito()
                                    vaciarCarrito() // Aquí se borra el carrito, pero ultimoPedido ya está a salvo
                                    onResult(true)
                                } else onResult(false)
                            }
                        } else onResult(false)
                    }
                } else onResult(false)
            }
            override fun onFailure(call: retrofit2.Call<Usuario>, t: Throwable) { onResult(false) }
        })
    }

    private fun descontarStockDeCarrito() {
        carrito.forEach { item ->
            val producto = item.producto
            val cantidadComprada = item.cantidad
            val nuevoStock = (producto.stock - cantidadComprada).coerceAtLeast(0)

            val index = _productos.indexOfFirst { it.id == producto.id }
            if (index != -1) _productos[index] = producto.copy(stock = nuevoStock)

            if (producto.id != null) {
                api.actualizarProducto(producto.id, producto.copy(stock = nuevoStock)).enqueue(object : Callback<Producto>{
                    override fun onResponse(call: Call<Producto>, response: Response<Producto>) {}
                    override fun onFailure(call: Call<Producto>, t: Throwable) {}
                })
            }
        }
    }

    fun cargarPedidosConfirmados() {
        pedidoDao.getPedidosConfirmados { lista ->
            _pedidos.clear()
            _pedidos.addAll(lista)
        }
    }

    // Ya no usamos este para la compra real, pero lo dejo por si lo usas en otro lado
    fun crearPedidoPendiente(metodoPago: String) {
        val usuario = usuarioActual.value ?: return
        val productosPedido = carrito.flatMap { item -> List(item.cantidad) { item.producto } }
        val total = totalCarrito()
        val pedido = Pedido(
            numeroPedido = (10000..99999).random(),
            productos = productosPedido,
            total = total,
            usuario = usuario,
            estado = Estado.PENDIENTE
        )
        _pedidos.add(pedido)
        ultimoPedido = pedido
        vaciarCarrito()
    }

    fun totalVentas(): Double = _pedidos.filter { it.estado == Estado.CONFIRMADO }.sumOf { it.total }
    fun productosActivos(): Int = _productos.size
    fun cargarProductosDesdeApi() { productoDao.getProductos { l -> if (l != null) { _productos.clear(); _productos.addAll(l) } } }
    fun cargarUsuarios() { RetrofitClient.api.getUsuarios().enqueue(object : Callback<List<Usuario>> { override fun onResponse(c: Call<List<Usuario>>, r: Response<List<Usuario>>) { r.body()?.let { usuarios.clear(); usuarios.addAll(it) } }; override fun onFailure(c: Call<List<Usuario>>, t: Throwable) {} }) }
}