package com.example.evatiendadeportes.dao

import com.example.evatiendadeportes.Model.Estado
import com.example.evatiendadeportes.Model.Pedido
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.remote.RetrofitClient

class PedidoDao {
    private val api = RetrofitClient.api

    fun crearPedido(userId: Long, productos: List<Producto>, onResult: (Pedido?) -> Unit) {
        api.crearPedido(userId).enqueue(object : retrofit2.Callback<Pedido> {
            override fun onResponse(call: retrofit2.Call<Pedido>, response: retrofit2.Response<Pedido>) {
                val pedidoCreado = response.body()
                if (pedidoCreado != null) {
                    productos.forEach { producto ->
                        api.agregarProducto(pedidoCreado.id!!, producto.id!!)
                            .enqueue(object : retrofit2.Callback<Pedido> {
                                override fun onResponse(call: retrofit2.Call<Pedido>, response: retrofit2.Response<Pedido>) {}
                                override fun onFailure(call: retrofit2.Call<Pedido>, t: Throwable) {}
                            })
                    }
                }
                onResult(pedidoCreado)
            }
            override fun onFailure(call: retrofit2.Call<Pedido>, t: Throwable) {
                onResult(null)
            }
        })
    }

    fun confirmarPedido(pedidoId: Long, onResult: (Boolean) -> Unit) {
        api.cambiarEstado(pedidoId, "CONFIRMADO")
            .enqueue(object : retrofit2.Callback<Pedido> {
                override fun onResponse(call: retrofit2.Call<Pedido>, response: retrofit2.Response<Pedido>) {
                    onResult(response.isSuccessful)
                }
                override fun onFailure(call: retrofit2.Call<Pedido>, t: Throwable) {
                    onResult(false)
                }
            })
    }

    fun getPedidosConfirmados(onResult: (List<Pedido>) -> Unit) {
        api.getPedidos().enqueue(object : retrofit2.Callback<List<Pedido>> {
            override fun onResponse(call: retrofit2.Call<List<Pedido>>, response: retrofit2.Response<List<Pedido>>) {
                val lista = response.body()?.filter { it.estado == Estado.CONFIRMADO } ?: emptyList()
                onResult(lista)
            }
            override fun onFailure(call: retrofit2.Call<List<Pedido>>, t: Throwable) {
                onResult(emptyList())
            }
        })
    }}