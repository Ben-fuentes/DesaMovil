package com.example.evatiendadeportes.Model

enum class Rol { ADMIN, CLIENTE }


data class Usuario(
    val id: Long? = null,
    val nombreCompleto: String,
    val nombreUser: String,
    val contrasenia: String,
    val rol: Rol = Rol.CLIENTE,
    val metodoPago: String? = null

)