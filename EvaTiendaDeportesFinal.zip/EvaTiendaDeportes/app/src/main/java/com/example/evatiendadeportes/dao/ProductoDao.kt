package com.example.evatiendadeportes.dao

import android.util.Log
import com.example.evatiendadeportes.Model.Producto
import com.example.evatiendadeportes.remote.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductoDao {

    private val api = RetrofitClient.api   // usa el mismo api del RetrofitClient

    fun getProductos(callback: (List<Producto>?) -> Unit) {
        api.getProductos().enqueue(object : Callback<List<Producto>> {
            override fun onResponse(
                call: Call<List<Producto>>,
                response: Response<List<Producto>>
            ) {
                callback(response.body())
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun getProducto(id: Long, callback: (Producto?) -> Unit) {
        api.getProducto(id).enqueue(object : Callback<Producto> {
            override fun onResponse(call: Call<Producto>, response: Response<Producto>) {
                callback(response.body())
            }

            override fun onFailure(call: Call<Producto>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun crearProducto(producto: Producto, callback: (Producto?) -> Unit) {
        RetrofitClient.api.crearProducto(producto).enqueue(object : Callback<Producto> {
            override fun onResponse(call: Call<Producto>, response: Response<Producto>) {
                if (response.isSuccessful) callback(response.body())
                else {
                    Log.e("API", "Error al crear producto: ${response.code()} - ${response.errorBody()?.string()}")
                    callback(null)
                }
            }

            override fun onFailure(call: Call<Producto>, t: Throwable) {
                Log.e("API", "Fallo de conexión: ${t.message}")
                callback(null)
            }
        })
    }


    fun actualizarProducto(id: Long, producto: Producto, callback: (Producto?) -> Unit) {
        api.actualizarProducto(id, producto).enqueue(object : Callback<Producto> {
            override fun onResponse(call: Call<Producto>, response: Response<Producto>) {
                callback(response.body())
            }

            override fun onFailure(call: Call<Producto>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun borrarProducto(id: Long, callback: (Boolean) -> Unit) {
        api.borrarProducto(id).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                callback(response.isSuccessful)
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                callback(false)
            }
        })
    }
}
