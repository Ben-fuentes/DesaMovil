package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable
fun DashboardAdminScreen(
    navController: NavController,
    viewModel: ProductoViewModel
) {
    val usuario = viewModel.usuarioActual.value
    val colores = MaterialTheme.colorScheme

    if (usuario?.rol?.name != "ADMIN") {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Acceso denegado.", color = colores.error)
        }
        return
    }

    // Datos del Dashboard
    // Nota: Aquí podrías usar viewModel.totalVentas() si quieres el total real acumulado
    val totalVentas = viewModel.ultimoPedido?.total ?: 0.0
    val pedidosPendientes = if (viewModel.ultimoPedido != null) 1 else 0
    val productosActivos = viewModel.productos.size

    val notificaciones = when {
        pedidosPendientes > 0 -> "Tienes pedidos sin revisar"
        productosActivos == 0 -> "No hay productos activos"
        else -> "Todo en orden"
    }

    MenuLateral(
        viewModel = viewModel,
        navController = navController
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            Text(
                "Dashboard del Administrador",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(Modifier.height(20.dp))

            // Tarjeta: Resumen de ventas
            DashboardCard(
                titulo = "Resumen de ventas",
                contenido = "Total vendido: $${"%.2f".format(totalVentas)}"
            )

            Spacer(Modifier.height(16.dp))

            // Tarjeta: Pedidos pendientes
            DashboardCard(
                titulo = "Pedidos pendientes",
                contenido = "$pedidosPendientes pedidos sin revisar"
            )

            Spacer(Modifier.height(16.dp))

            // Tarjeta: Productos activos
            DashboardCard(
                titulo = "Productos activos",
                contenido = "$productosActivos productos disponibles"
            )

            Spacer(Modifier.height(16.dp))

            // Tarjeta: Notificaciones
            DashboardCard(
                titulo = "Notificaciones",
                contenido = notificaciones
            )
        }
    }
}

@Composable
fun DashboardCard(titulo: String, contenido: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
        // CAMBIO 1: Contenedor con color Primary
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // CAMBIO 2: Textos con color Secondary
            Text(
                text = titulo,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = contenido,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}