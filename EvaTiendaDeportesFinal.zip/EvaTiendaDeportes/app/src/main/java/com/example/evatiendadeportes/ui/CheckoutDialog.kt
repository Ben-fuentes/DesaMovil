package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import androidx.compose.ui.graphics.Color

@Composable
fun CheckoutDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    viewModel: ProductoViewModel,
    onConfirm: (metodoPago: String) -> Unit
) {
    if (!showDialog) return

    var metodoPago by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf<String?>(null) }

    val metodos = listOf("Crédito", "Débito", "Efectivo en el hogar")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Método de pago")
                IconButton(onClick = onDismiss) {
                    Text("X")
                }
            }
        },
        text = {
            Column {
                metodos.forEach { metodo ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = metodoPago == metodo,
                            onClick = {
                                metodoPago = metodo
                                mensajeError = null // limpiar mensaje al seleccionar
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(metodo)
                    }
                }

                mensajeError?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (metodoPago.isNotEmpty()) {
                        viewModel.crearPedidoYConfirmar(metodoPago) { ok ->
                            if (ok) {
                                onConfirm(metodoPago)
                            } else {
                                viewModel.mensaje.value = "Error al crear el pedido"
                            }
                        }
                    } else {
                        mensajeError = "Debes escoger un método de pago"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) {
                Text("Confirmar")
            }
        }
    )
}