package com.example.evatiendadeportes.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.evatiendadeportes.viewmodel.ProductoViewModel
import kotlinx.coroutines.launch


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuLateral(
    viewModel: ProductoViewModel,
    navController: NavController,
    content: @Composable () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val usuario = viewModel.usuarioActual.value
    val c = MaterialTheme.colorScheme
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    val tituloPantalla = when (currentRoute) {
        "catalogo" -> "Catálogo"
        "carrito" -> "Carrito"
        "admin" -> "Administración"
        "dashboard_admin" -> "Dashboard Admin"
        "inicio_sesion" -> "Iniciar Sesión"
        "perfil" -> "Perfil"
        "promociones" -> "Promociones"
        else -> "Tienda Deportes"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = c.primary,
                drawerContentColor = Color.White
            ) {

                Spacer(Modifier.height(16.dp))

                NavigationDrawerItem(
                    label = { Text("Catálogo") },
                    selected = currentRoute == "catalogo",
                    onClick = {
                        navController.navigate("catalogo")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary,
                        selectedTextColor = Color.Black,
                        selectedIconColor = Color.White
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Carrito") },
                    selected = currentRoute == "carrito",
                    onClick = {
                        navController.navigate("carrito")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary,
                        selectedTextColor = Color.Black,
                        selectedIconColor = Color.White
                    )
                )

                if (viewModel.esAdministrador()) {
                    NavigationDrawerItem(
                        label = { Text("Administración") },
                        selected = currentRoute == "admin",
                        onClick = {
                            navController.navigate("admin")
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            unselectedContainerColor = Color.Transparent,
                            unselectedTextColor = Color.White,
                            unselectedIconColor = Color.White,
                            selectedContainerColor = c.secondary,
                            selectedTextColor = Color.Black,
                            selectedIconColor = Color.White
                        )
                    )
                    if (viewModel.esAdministrador()) {
                        NavigationDrawerItem(
                            label = { Text("Clientes") },
                            selected = currentRoute == "clientes",
                            onClick = {
                                navController.navigate("clientes")
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                unselectedTextColor = Color.White,
                                unselectedIconColor = Color.White,
                                selectedContainerColor = c.secondary,
                                selectedTextColor = Color.Black,
                                selectedIconColor = Color.White
                            )
                        )
                    }
                    if (viewModel.esAdministrador()) {
                        NavigationDrawerItem(
                            label = { Text("Crear Producto") },
                            selected = currentRoute == "crear_producto",
                            onClick = {
                                navController.navigate("crear_producto")
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                unselectedTextColor = Color.White,
                                unselectedIconColor = Color.White,
                                selectedContainerColor = c.secondary,
                                selectedTextColor = Color.Black,
                                selectedIconColor = Color.White
                            )
                        )

                        NavigationDrawerItem(
                            label = { Text("Listado Productos") },
                            selected = currentRoute == "listado_productos",
                            onClick = {
                                navController.navigate("listado_productos")
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                unselectedTextColor = Color.White,
                                unselectedIconColor = Color.White,
                                selectedContainerColor = c.secondary,
                                selectedTextColor = Color.Black,
                                selectedIconColor = Color.White
                            )
                        )
                    }

                    // Dashboard Admin
                    NavigationDrawerItem(
                        label = { Text("Dashboard Admin") },
                        selected = currentRoute == "dashboard_admin",
                        onClick = {
                            navController.navigate("dashboard_admin")
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            unselectedContainerColor = Color.Transparent,
                            unselectedTextColor = Color.White,
                            unselectedIconColor = Color.White,
                            selectedContainerColor = c.secondary,
                            selectedTextColor = Color.Black,
                            selectedIconColor = Color.White
                        )
                    )
                }

                NavigationDrawerItem(
                    label = { Text("Promociones") },
                    selected = currentRoute == "promociones",
                    onClick = {
                        navController.navigate("promociones")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary,
                        selectedTextColor = Color.Black,
                        selectedIconColor = Color.White
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Perfil") },
                    selected = currentRoute == "perfil",
                    onClick = {
                        navController.navigate("perfil")
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.secondary,
                        selectedTextColor = Color.Black,
                        selectedIconColor = Color.White
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Cerrar Sesión") },
                    selected = false,
                    onClick = {
                        viewModel.cerrarSesion()
                        navController.navigate("inicio_sesion") {
                            popUpTo(0)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = Color.White,
                        unselectedIconColor = Color.White,
                        selectedContainerColor = c.error,
                        selectedTextColor = Color.Black,
                        selectedIconColor = Color.White
                    )
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(tituloPantalla) },
                    navigationIcon = {
                        IconButton(onClick = {
                            scope.launch { drawerState.open() }
                        }) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = c.primary,
                        titleContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                content()
            }
        }
    }
}
