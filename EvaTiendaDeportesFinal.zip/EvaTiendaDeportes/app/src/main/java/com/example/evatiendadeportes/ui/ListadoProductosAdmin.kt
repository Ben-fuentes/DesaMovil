package com.example.evatiendadeportes.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evatiendadeportes.Model.Categoria
import com.example.evatiendadeportes.R
import com.example.evatiendadeportes.ui.theme.AzulOscuro
import com.example.evatiendadeportes.viewmodel.ProductoViewModel

@Composable
fun ListadoProductosAdmin(
    viewModel: ProductoViewModel,
    navController: NavController
) {
    val context = LocalContext.current
    if (!viewModel.esAdministrador()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No tienes permisos para acceder a esta sección")
        }
        return
    }

    // Estado del buscador y filtros
    var busqueda by remember { mutableStateOf("") }
    var filtro by remember { mutableStateOf("A-Z") }

    val colores = MaterialTheme.colorScheme

    // Mapa de categoría → imagen por defecto
    val imagenPorCategoria = mapOf(
        Categoria.BMX to R.drawable.bmx,
        Categoria.SKATE to R.drawable.skte,
        Categoria.ROLLER to R.drawable.roller
    )

    // Filtrado de productos
    val productosFiltrados = viewModel.productos
        .filter { it.nombre.contains(busqueda, ignoreCase = true) }
        .let { lista ->
            when (filtro) {
                "A-Z" -> lista.sortedBy { it.nombre }
                "Z-A" -> lista.sortedByDescending { it.nombre }
                "Precio ↑" -> lista.sortedBy { it.precio }
                "Precio ↓" -> lista.sortedByDescending { it.precio }
                else -> lista
            }
        }

    MenuLateral(viewModel, navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Buscador
            OutlinedTextField(
                value = busqueda,
                onValueChange = { busqueda = it },
                label = { Text("Buscar producto") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            // Filtro
            FiltroListado(
                filtroActual = filtro,
                onFiltroCambiar = { filtro = it }
            )

            Spacer(Modifier.height(16.dp))

            LazyColumn {
                items(productosFiltrados) { producto ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clickable { /* Aquí podrías abrir detalle si quieres */ },
                        colors = CardDefaults.cardColors(
                            containerColor = colores.primary
                        )
                    ) {
                        Row(modifier = Modifier.padding(16.dp)) {

                            val imagenResId =
                                producto.imagenResId ?: imagenPorCategoria[producto.categoria] ?: R.drawable.gato

                            Image(
                                painter = painterResource(id = imagenResId),
                                contentDescription = producto.nombre,
                                modifier = Modifier
                                    .size(100.dp)
                                    .padding(end = 16.dp)
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text(producto.nombre,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White
                                )
                                Text(producto.descripcion,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White
                                )
                                Text("Categoría: ${producto.categoria}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White
                                )
                                Text("Precio: $${producto.precio}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White
                                )
                                Text("Stock: ${producto.stock}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White
                                )

                                Spacer(Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        producto.id?.let { id ->
                                            viewModel.eliminarProducto(id) { exito ->
                                                if (exito) {
                                                    Toast.makeText(context, "Producto eliminado", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "No se puede borrar el producto (posiblemente esté en un pedido)", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary,
                                        contentColor = Color.Black
                                    )
                                ) {
                                    Text("Eliminar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FiltroListado(
    filtroActual: String,
    onFiltroCambiar: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(
            onClick = { expanded = true },
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        ) {
            Text("Ordenar: $filtroActual")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(text = { Text("A-Z") }, onClick = {
                onFiltroCambiar("A-Z")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Z-A") }, onClick = {
                onFiltroCambiar("Z-A")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Precio ↑") }, onClick = {
                onFiltroCambiar("Precio ↑")
                expanded = false
            })
            DropdownMenuItem(text = { Text("Precio ↓") }, onClick = {
                onFiltroCambiar("Precio ↓")
                expanded = false
            })
        }
    }
}